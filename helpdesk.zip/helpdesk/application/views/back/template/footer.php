<footer class="main-footer">
    <strong>Copyright &copy; 2024 <a href="https://wop.co.id/">PT. WAHANA OPTIMA PERMAI</a>.</strong>
    All rights reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
</div>
<!-- /.control-sidebar -->